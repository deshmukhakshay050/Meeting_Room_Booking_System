<?php

include('init.php');


$datefrom=$_POST["dfr"];
$dateto=$_POST["dto"];

$name=$_POST["name"];
$email=$_SESSION['user'];
$guests=$_POST["guests"];
$number=$_POST["number"];

$tstart=$_POST["tstart"];
$tend=$_POST["tend"];

$hidden=$_POST["hidden"];


$datefrom= date("Y-m-d", strtotime($datefrom) );

$dateto= date("Y-m-d", strtotime($dateto) );

$tstart= date("h:i:s", strtotime($tstart) );

$tend=date("h:i:s", strtotime($tend) );


$table=$hidden;
	$table1="";

	if ($table=="compbooking")
	{
		$table1="compbooked";
	}
	else if ($table=="itbooking")
	{
		$table1="itbooked";
	}
	else if ($table=="entcbooking")
	{
		$table1="entcbooked";
	}
######################################case 1 

$sql_query="select datefrom from ".$table." where datefrom ='$datefrom' or dateto = '$dateto' and (tstart='$tstart' or tend='$tend');";

$result=mysqli_query($conn,$sql_query);


if(mysqli_num_rows($result))
{


$sql_query2="select tstart,tend from ".$table1." where datefrom ='$datefrom' or dateto = '$dateto';";

	$result1=mysqli_query($conn,$sql_query2);
	$flag=1;
	while($row = mysqli_fetch_assoc($result1))
	{
		if (($tstart<$row['tstart'] && $tend<=$row['tstart']) || ($tstart>=$row['tend'] && $tend>$row['tend']))
		{
			$flag=1;
			
		}
		else
		{
			$flag=0;
			break;
		}

	   
	}
	if ($flag==0)
	{
	echo'<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<style>
		* {
    box-sizing: border-box;
	}
		html,body{
				height: 100%;
				margin:0px;

			background-image: -webkit-linear-gradient(rgba(25,26,24,0.4), rgba(30,36,34,0.89)),url(boardroom.jpg);
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: cover;	
			overflow:auto;
		
		</style>
	</head>
	<body>';
	echo '<center style="position:relative;top:150px;"><div style="background-color:;;width:40%;height:300px;box-shadow: 1px 1px 4px 1px #ddd;
background: #f5f5f5;">';
	echo "<br><br><br>";
	echo "Choose other than these slots  <br>";
	$result1=mysqli_query($conn,$sql_query2);
	
	while($row = mysqli_fetch_assoc($result1))
	{


	   echo $row['tstart'],"-",$row['tend'],'<br>';

	}


	echo'</div></center>';
	
	echo '</body>';
	echo'</html>';
	exit;
	
	}
	goto l;

}

l:
echo'<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<style>
		* {
    box-sizing: border-box;
	}
		html,body{
				height: 100%;
				margin:0px;

			background-image: -webkit-linear-gradient(rgba(25,26,24,0.4), rgba(30,36,34,0.89)),url(boardroom.jpg);
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: cover;	
			overflow:auto;
		
		</style>
	</head>
	<body>';
	
	

	
	$sql = "INSERT INTO  ".$table."(NAME,EMAIL,CONTACTNO,NOG,DATEFROM,DATETO,TSTART,TEND)
	VALUES ('$name', '$email',$number,$guests,'$datefrom','$dateto','$tstart','$tend');";


	$sql1 = "INSERT INTO  ".$table1."(datefrom,dateto,tstart,tend)
	VALUES ('$datefrom','$dateto','$tstart','$tend');";

	mysqli_query($conn, $sql1);

	if (mysqli_query($conn, $sql)) {
	    echo "<script>
		alert('Booking done and confirmation msg is sent to your email please open it');
		window.location.href='email.php';
		;
		</script>";
	} else {
	    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
		
	echo'</div></center>';
	
	echo '</body>';
	echo'</html>';
	
	exit;






?>