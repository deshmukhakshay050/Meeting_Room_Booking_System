 

<?php


include('init.php');



if (isset($_SESSION['user'])) {
  


 } 
else
{



$username=$_POST["email"];
$userpass=$_POST["pass"];




$sql_query="select name from user where email like '$username' and password like '$userpass';";

$result=mysqli_query($conn,$sql_query);



if(mysqli_num_rows($result)==1)
{


 $_SESSION['user'] = $username;
 

 

echo "<script>
	alert('SignIn Successful');
	window.location.href='index.html';
	</script>";

    exit;



}

else
{


echo "<script>
	alert('Check For Credientials');
	window.location.href='login.html';
	</script>";

    exit;



}
	

	}



?>





