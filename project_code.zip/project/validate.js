function comp(){


	var name=document.getElementById('name');
	//var email=document.getElementById('email');
	var number=document.getElementById('number');
	var guests=document.getElementById('guests');
	
	var dfr=document.getElementById('dfr');
	var dt2 = new Date(dfr.value);
	var dt1=new Date(Date.now());


	var dto=document.getElementById('dto');
	var dt3 = new Date(dto.value);

	var tstart=document.getElementById('tstart');
	var tend=document.getElementById('tend');
	


	

	var regname = /^[a-zA-Z ]{2,30}$/;

	if (name.value.length==0 || (regname.test(name.value)==false))
	{
		name.placeholder="Required";
		name.focus();
		name.value="";

	    name.style.borderBottomColor ="#FE4567";
 	 	//alert("Name required");

 	 	return false;
	}

	var regemail = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	


	 

	  var regnumber=/^[0]?[789]\d{9}$/;

	  if(number.value.length!=10 || (regnumber.test(number.value)))
	  {

	  	number.value="";
	  	number.placeholder="Please enter 10 digit mobile number and dont give space in betwwen";
	  	number.focus();
	  	number.style.borderBottomColor ="#FE4567";
	  	return false;

	  
	  }

	 
	 if(guests.value.length<=0 || guests.value<=0 || guests.value>=200)
	 {
		guests.placeholder="Please enter bwteen 1 to 200";
		guests.value="";
		guests.focus();
		guests.style.borderBottomColor="#FE4567";
		return false;

	}
	

	
	if(( Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate()) ) /(1000 * 60 * 60 * 24)))<0)
	{
		alert("choose valid current date from");
		return false;
	}

	if(( Math.floor((Date.UTC(dt3.getFullYear(), dt3.getMonth(), dt3.getDate()) - Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) ) /(1000 * 60 * 60 * 24)))<0)
	{
		alert("choose valid date to");
		return false;
	}

	
	var timefrom = new Date();
	temp = tstart.value.split(":");
	timefrom.setHours((parseInt(temp[0]) - 1 + 24) % 24);
	timefrom.setMinutes(parseInt(temp[1]));

	var timeto = new Date();
	temp = tend.value.split(":");
	timeto.setHours((parseInt(temp[0]) - 1 + 24) % 24);
	timeto.setMinutes(parseInt(temp[1]));

	if (timeto < timefrom) 
	{
	    alert('start time should be smaller');
		return false;

	
	}


	return true;
}
function it(){


	var name=document.getElementById('name');
	//var email=document.getElementById('email');
	var number=document.getElementById('number');
	var guests=document.getElementById('guests');
	

	var dfr=document.getElementById('dfr');
	var dt2 = new Date(dfr.value);
	var dt1=new Date(Date.now());


	var dto=document.getElementById('dto');
	var dt3 = new Date(dto.value);

	var tstart=document.getElementById('tstart');
	var tend=document.getElementById('tend');

	

	var regname = /^[a-zA-Z ]{2,30}$/;

	if (name.value.length==0 || (regname.test(name.value)==false))
	{
		name.placeholder="Required";
		name.focus();
		name.value="";

	    name.style.borderBottomColor ="#FE4567";
 	 	//alert("Name required");

 	 	return false;
	}

	var regemail = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	


	

	  var regnumber=/^[0]?[789]\d{9}$/;

	  if(number.value.length!=10 || regnumber.test(number.value))
	  {

	  	number.value="";
	  	number.placeholder="Please enter 10 digit mobile number and dont give space in betwwen";
	  	number.focus();
	  	number.style.borderBottomColor ="#FE4567";
	  	return false;

	  
	  }

	  if(guests.value.length<=0 || guests.value<=0 || guests.value>=200)
	{
		guests.placeholder="Please enter bwteen 1 to 200";
		guests.value="";
		guests.focus();
		guests.style.borderBottomColor="#FE4567";
		return false;

	}


	if(( Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate()) ) /(1000 * 60 * 60 * 24)))<0)
	{
		alert("choose valid current date from");
		return false;
	}

	if(( Math.floor((Date.UTC(dt3.getFullYear(), dt3.getMonth(), dt3.getDate()) - Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) ) /(1000 * 60 * 60 * 24)))<0)
	{
		alert("choose valid date to");
		return false;
	}

	
	var timefrom = new Date();
	temp = tstart.value.split(":");
	timefrom.setHours((parseInt(temp[0]) - 1 + 24) % 24);
	timefrom.setMinutes(parseInt(temp[1]));

	var timeto = new Date();
	temp = tend.value.split(":");
	timeto.setHours((parseInt(temp[0]) - 1 + 24) % 24);
	timeto.setMinutes(parseInt(temp[1]));

	if (timeto < timefrom) 
	{
	    alert('start time should be smaller');
	    return false;
	}

	return true;
	

}

function entc(){

	

	var name=document.getElementById('name');
	
	var number=document.getElementById('number');
	var guests=document.getElementById('guests');
	
	var dfr=document.getElementById('dfr');
	var dt2 = new Date(dfr.value);
	var dt1=new Date(Date.now());


	var dto=document.getElementById('dto');
	var dt3 = new Date(dto.value);

	var tstart=document.getElementById('tstart');
	var tend=document.getElementById('tend');

	

	var regname = /^[a-zA-Z ]{2,30}$/;

	if (name.value.length==0 || (regname.test(name.value)==false))
	{
		name.placeholder="Required";
		name.focus();
		name.value="";

	    name.style.borderBottomColor ="#FE4567";
 	 	//alert("Name required");

 	 	return false;
	}

	var regemail = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	


	

	  var regnumber=/^[0]?[789]\d{9}$/;

	  if(number.value.length!=10 || regnumber.test(number.value)==false)
	  {

	  	number.value="";
	  	number.placeholder="Please enter 10 digit mobile number and dont give space in betwwen";
	  	number.focus();
	  	number.style.borderBottomColor ="#FE4567";
	  	return false;

	  
	  }

	  if(guests.value.length<=0 || guests.value<=0 || guests.value>=200||guests.test("")==false)
	{
		guests.placeholder="Please enter bwteen 1 to 200";
		guests.value="";
		guests.style.borderBottomColor="#FE4567";
		return false;

	}


	if(( Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate()) ) /(1000 * 60 * 60 * 24)))<0)
	{
		alert("choose valid current date from");
		return false;
	}

	if(( Math.floor((Date.UTC(dt3.getFullYear(), dt3.getMonth(), dt3.getDate()) - Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) ) /(1000 * 60 * 60 * 24)))<0)
	{
		alert("choose valid date to");
		return false;
	}

	
	var timefrom = new Date();
	temp = tstart.value.split(":");
	timefrom.setHours((parseInt(temp[0]) - 1 + 24) % 24);
	timefrom.setMinutes(parseInt(temp[1]));

	var timeto = new Date();
	temp = tend.value.split(":");
	timeto.setHours((parseInt(temp[0]) - 1 + 24) % 24);
	timeto.setMinutes(parseInt(temp[1]));

	if (timeto < timefrom) 
	{
	    alert('start time should be smaller');
	    return false;

	}
	

	return true;














}
