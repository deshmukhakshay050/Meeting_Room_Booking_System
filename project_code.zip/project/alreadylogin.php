<?php
include('init.php'); // Includes Login Script

if(isset($_SESSION['user'])){

echo "<script>
	alert('Already Logded In!');
	window.location.href='index.html';
	</script>";




}

else{

	header("location: login.html");

}


?>