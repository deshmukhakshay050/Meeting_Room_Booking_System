# Online Meeting Room System

The project provides the facilities for online booking of the seminar halls,audiorium and conference rooms.

## Getting Started

1)The HomePage provides three options for booking ENTC seminar hall,Comp Seminar Hall,It seminar hall.
2)Initially for booking user must register to our portal.
3)After signup user can book the corresponding room.
4)Thereafter the confirmation email will be send to user and user will be redirected to payment portal.




### Prerequisites


1)Xampp Server 

It is required to deploy the application
* [Dropwizard](https://www.apachefriends.org/download.html) - Installation link


2)Mysql 
Mysql is needed for database.
MariaDB is sufficient.

* [Dropwizard](* [Dropwizard](https://www.apachefriends.org/download.html) - Installation link



### Running The Application

1)Copy the project folder into lampp/htdocs/folder

2)Start the xampp server 

3)On the web browser run localhost/project/index.hml

4)The application portal is now opened where you can navigate and book the room according to your need.




## Built With

1)Eclipse Editor

2)Apache Framework




## Authors


1)Akshay Deshmukh.

2)Aviraj Korde.

3)Prashant Bhivsane.


## License

This project is licensed under PICT,PUNE


