
<?php


include('init.php');


$email=$_SESSION['user'];



$query = "SELECT * FROM compbooking where email= '$email';"; //You don't need a ; like you do in SQL


$result=mysqli_query($conn,$query);


if(mysqli_num_rows($result)==0)
{

echo "<script>
		alert('no bookings yet');
		window.location.href='comp.html';
		;
		</script>";
exit;

}
echo "<head>";

echo "<style>";
echo "

html,body{
				height: 100%;
				margin:0px;

			background-image: -webkit-linear-gradient(rgba(25,26,24,0.4), rgba(30,36,34,0.89)),url(boardroom.jpg);
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: cover;	
			overflow:auto;

		}

#customers {
    font-family: Trebuchet MS, Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
    position:relative;
    top:200px;
    height:300px;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:nth-child(odd){background-color: #f2f2f2;}


#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}

";


echo "</style></head>";


echo "<table id='customers'><th>EMAIL</th>
    <th>NOG</th><th>CONTACTNO</th><th>DATEFROM</th><th>DATETO</th><th>TIMESTART</th><th>TIMETO</th>"; // start a table tag in the HTML

while($row = mysqli_fetch_array($result))
{   


echo "<tr><td>" . $row['EMAIL'] . "</td><td>" . $row['NOG'] . "</td><td>" . $row['CONTACTNO'] . "</td><td>" . $row['DATEFROM'] . "</td><td>" . $row['DATETO'] . "</td><td>" . $row['TSTART'] . "</td><td>" . $row['TEND'] . "</td></tr>";  //$row['index'] the index here is a field n








}

echo "</table>"; //Close the table in HTML




?>