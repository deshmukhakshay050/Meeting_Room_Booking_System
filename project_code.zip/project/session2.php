<?php
include('init.php'); // Includes Login Script

if(isset($_SESSION['user'])){

header("location:entc.html");



}

else{

	header("location:login.html");

}


?>