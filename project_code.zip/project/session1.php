<?php
include('init.php'); // Includes Login Script

if(isset($_SESSION['user'])){

header("location: it.html");



}

else{

	header("location: login.html");

}


?>