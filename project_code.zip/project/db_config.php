<?php
$servername = 'localhost';
$dbname='new-project';
$username = 'root';
$password = '';

// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);

// Check connection
if ($conn==false) {
    die("Connection failed: " . mysqli_connect_error);
}
//echo "Connected successfully";

$memail=$_POST["memail"];
$mname=$_POST["mname"];
$mnumber=$_POST["mnumber"];
$mguests=$_POST["guest"];
$startDate=$_POST["dateFrom"];
$endDate=$_POST["dateTo"];
$startTime=$_POST["timeStart"];
$endTime=$_POST["timeEnd"];


$timestampone=$startDate. "".$startTime;
$timestamptwo=$endDate. "".$endTime;

//$sql = "SELECT uid FROM booking-info-comp WHERE usertimestart = '$timestampone'";

$sql_insert = "INSERT INTO `booking-info-comp`(`username`, `usermail`, `usermobile`, `userguests`, `usertimestart`, `usertimeend`) VALUES ('$mname','$memail','$mnumber',$mguests,'$timestampone','$timestamptwo')";



         if (mysqli_query($conn, $sql_insert)) {
            header("Location:email.php");
            echo "New record created successfully";
}       else {
            echo "Error: " . $sql_insert . "<br>" . mysqli_error($conn);
}




echo ($timestampone);

?>
