<?php
require('init.php'); // Includes Login Script




if(isset($_SESSION['user'])) {


echo "<script>
	alert('LogOut ScucessFull');
	window.location.href='index.html';
	</script>";

  

unset($_SESSION['user']);



exit;


}

else{



echo "<script>
	alert('LogIn First');
	window.location.href='index.html';
	</script>";

    exit;

}
?>