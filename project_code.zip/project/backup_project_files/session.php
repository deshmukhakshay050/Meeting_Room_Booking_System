<?php
include('logincheck.php'); // Includes Login Script

if(isset($_SESSION['user'])){

header("location: book-form-comp.html");



}

else{

	header("location: login.html");

}


?>