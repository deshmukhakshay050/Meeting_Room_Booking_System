 

<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "wtl";  


session_start();
// Create connection
$conn = mysqli_connect($servername,$username,$password,$db_name);  
 

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}




if (isset($_SESSION['user'])) {
  
 } 
else
{

#include('logout.php');


#if(($_SESSION['logout'])=="False"){


$username=$_POST["email"];
$userpass=$_POST["pass"];







$sql_query="select name from user where email like '$username' and password like '$userpass';";

$result=mysqli_query($conn,$sql_query);



if(mysqli_num_rows($result)==1)
{




 $_SESSION['user'] = $username;
 

echo "<script>
	alert('SignIn Successful');
	window.location.href='index.html';
	</script>";

    exit;



}

else
{
echo "SignIn Failed:-Check For valid data!!"; 

}
	}



?>





