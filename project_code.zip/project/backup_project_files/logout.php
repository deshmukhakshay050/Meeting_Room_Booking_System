<?php
require('logincheck.php'); // Includes Login Script



$_SESSION['logout']= "False";



if(isset($_SESSION['user'])){



session_destroy();



}

else{


$_SESSION['logout'] = "True";


echo "<script>
	alert('LogIn First');
	window.location.href='index.html';
	</script>";

    exit;

}
?>