function check()
{

 var x=document.getElementById('email');
 var y=document.getElementById('pass');


var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;


  if(x.value.length==0){
 	// alert('Email Adress cannot be empty');
 	 
 	x.placeholder="Required";
    x.style.borderBottomColor = "#FE4567";

 	 return false;

 }
    

 if (reg.test(x.value) == false) 
 {
          
            x.placeholder="Invalid Email Id";
            x.value="";
            x.focus();
            x.style.borderBottomColor = "#FE4567";
            return false;
  }

   if (y.value.length==0 || y.value=='****')
 {
 	//alert('Password Adress cannot be empty');
 	y.placeholder="Password  cannot be empty";
 	y.style.borderBottomColor="#FE4567";
 	return false;
 }

}



