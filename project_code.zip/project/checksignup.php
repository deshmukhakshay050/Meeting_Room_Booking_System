<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "wtl";  



// Create connection
$conn = mysqli_connect($servername,$username,$password,$db_name);  
 

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$email=$_POST["email"];
$password=$_POST["password"];
$name=$_POST["name"];
$number=$_POST["number"];
$email=$_POST["email"];
$confirmpassword=$_POST["confirmpassword"];



$sql_query1="select name from user where EMAIL like '$email';";

$result1=mysqli_query($conn,$sql_query1);



if(mysqli_num_rows($result1)==1)
{


 	echo "<script>
	alert('Email Not Available Try another');
	window.location.href='signup.html';
	</script>";

    exit;
  exit;


}

$sql = "INSERT INTO user (NAME,EMAIL,CONTACTNO,PASSWORD,CONFIRM)
VALUES ('$name', '$email',$number,'$password','$confirmpassword');";

if (mysqli_query($conn, $sql)) {
    echo "<script>
	alert('SignUp ScucessFull');
	window.location.href='index.html';
	</script>";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);



?>