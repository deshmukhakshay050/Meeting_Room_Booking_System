
<?php


include('init.php');

if (isset($_SESSION['user'])) {

  
$email=$_SESSION['user'] ;

echo $email;

$to      = $email;
$subject = 'Confirmation';
$message = '<a href="http://localhost/project/payment.html">Open This For payment</a>';


$headers= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";



 mail($to, $subject, $message, $headers);

 } 
else
{
echo "hello";


}

 echo "<script>
		window.location.href='payment.html';
		;
		</script>";

?>
