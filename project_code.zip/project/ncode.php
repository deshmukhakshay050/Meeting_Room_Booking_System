<?php

// Initialize variable for database credentials
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'new-project';

//Create database connection
  $conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

//Check connection was successful
  if ($conn->connect_errno) {
     printf("Failed to connect to database");
     exit();
  }

  $sql= "SELECT * FROM `booking-info-comp`";
//Fetch 3 rows from actor table
  $result = $conn->query($sql) or die($conn->error);

//Initialize array variable
  $dbdata = array();

//Fetch into associative array
  while ( $row = $result->fetch_assoc())  {
	$dbdata[]=$row;
  }

//Print array in JSON format
 echo json_encode($dbdata);

?>
