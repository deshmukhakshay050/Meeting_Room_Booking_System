<?php
$servername = 'localhost';
$dbname='new-project';
$username = 'root';
$password = '';
$conn = mysqli_connect($servername, $username, $password,$dbname);

// Check connection
if ($conn==false) {
    die("Connection failed: " . mysqli_connect_error);
}
?>
