function check()
{


	var name=document.getElementById('name');
	var email=document.getElementById('email');
	var number=document.getElementById('number');
	var password=document.getElementById('password');
	var confirmpassword=document.getElementById('confirmpassword');
	
	
	
	var regname = /^[a-zA-Z ]{2,30}$/;

	if (name.value.length==0 || (regname.test(name.value)==false))
	{
		name.placeholder="Required";
		name.focus();
		name.value="";

	    name.style.borderBottomColor ="#FE4567";
 	 	//alert("Name required");

 	 	return false;
	}


	var regemail = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	if (regemail.test(email.value) == false) 
	 {
	          
	            email.placeholder="Invalid Email Id";
	            email.value="";
	            email.style.borderBottomColor ="#FE4567";
	            email.focus();
	            return false;
	  }

	

	var regnumber=/^[0]?[789]\d{9}$/;

		if(number.value.length!=10 || (regnumber.test(number.value)))
		  {
		  	number.value="";
		  	number.placeholder="Please enter 10 digit mobile number and dont give space in betwwen";
		  	number.focus();
		  	return false;
		  }	


	   if (password.value.length==0)
	 	{
		 	password.placeholder="Password  cannot be empty";
		 	return false;
	 	}

	  if (confirmpassword.value.length==0)
	 	{
		 	//alert('Password Adress cannot be empty');
		 	confirmpassword.placeholder="Password  cannot be empty";
		 	return false;
	 	}
	 	 if (password.value!=confirmpassword.value)
	 	{
		 	alert('Passwords Dont match');
		 	
		 	return false;
	 	}




}